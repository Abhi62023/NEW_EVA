import pyttsx3  # pip install pyttsx3
import speech_recognition as sr  # pip install SpeechRecognition
import datetime
import wikipedia  # pip install wikipedia
import webbrowser
import os
import smtplib
import random

# Initialize Text-to-Speech engine
engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[1].id)

# Speak text aloud
def speak(audio):
    engine.say(audio)
    engine.runAndWait()

# Greet the user
def wishMe():
    hour = int(datetime.datetime.now().hour)
    if 0 <= hour < 12:
        speak("Good Morning!")
    elif 12 <= hour < 17:
        speak("Good Afternoon!")
    elif 17 <= hour < 19:
        speak("Good Evening!")
    else:
        speak("Good Night!")
    speak("I am your virtual assistant EVA. Please tell me how may I help you.")

# Listen to user voice input and convert to text
def takeCommand():
    rr = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening...")
        rr.pause_threshold = 1
        audio = rr.listen(source)

    try:
        print("Recognizing...")
        query = rr.recognize_google(audio, language='en-in')
        print(f"User said: {query}\n")
    except Exception:
        print("Say that again please...")
        speak("I can't understand. Please say that again!")
        return "none"
    return query

# Send email via Gmail SMTP
def sendEmail(to, content):
    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.ehlo()
    server.starttls()
    server.login('xyz@gmail.com', '123')  # Replace with valid credentials
    server.sendmail('xyz@gmail.com', to, content)
    server.close()

# Process voice command logic
def process_command(query):
    query = query.lower()

    if 'wikipedia' in query:
        query = query.replace("wikipedia", "")
        try:
            results = wikipedia.summary(query, sentences=2)
            return f"According to Wikipedia: {results}"
        except:
            return "Sorry, I couldn't find that on Wikipedia."

    elif "hello" in query or "hello eva" in query:
        return "Hello! How may I help you?"

    elif "who are you" in query or "about you" in query or "your details" in query:
        return "I am EVA, an AI based virtual assistant created to help you. Try giving me a command!"

    elif 'who made you' in query or 'who created you' in query:
        return "Abhishek Chaturvedi created me! You can visit his LinkedIn profile at https://www.linkedin.com/in/aabhishekchaturvedii"

    elif 'open youtube' in query:
        webbrowser.open("https://www.youtube.com")
        return "Opening YouTube"

    elif 'open github' in query:
        webbrowser.open("https://www.github.com")
        return "Opening GitHub"

    elif 'open facebook' in query:
        webbrowser.open("https://www.facebook.com")
        return "Opening Facebook"

    elif 'open instagram' in query:
        webbrowser.open("https://www.instagram.com")
        return "Opening Instagram"

    elif 'open google' in query:
        webbrowser.open("https://www.google.com")
        return "Opening Google"

    elif 'open stackoverflow' in query:
        webbrowser.open("https://stackoverflow.com")
        return "Opening Stack Overflow"

    elif 'open gmail' in query:
        webbrowser.open("https://mail.google.com")
        return "Opening Gmail"

    elif 'open amazon' in query or 'shop online' in query:
        webbrowser.open("https://www.amazon.com")
        return "Opening Amazon"

    elif 'open flipkart' in query:
        webbrowser.open("https://www.flipkart.com")
        return "Opening Flipkart"

    elif 'open code' in query:
        try:
            codePath = "D:\\vs\\Microsoft VS Code\\Code.exe"  # Change to your VS Code path
            os.startfile(codePath)
            return "Opening Visual Studio Code"
        except:
            return "Sorry, I couldn't open Visual Studio Code. Please check the path."

    elif 'play music' in query:
        try:
            music_dir = 'E:\\My MUSIC'  # Change to your music folder
            songs = os.listdir(music_dir)
            os.startfile(os.path.join(music_dir, songs[0]))
            return "Playing music"
        except:
            return "Sorry, I couldn't play music. Please check the music folder path."

    elif 'play video' in query or 'video from pc' in query:
        try:
            video_dir = 'E:\\My Videos'  # Change to your video folder
            videos = os.listdir(video_dir)
            os.startfile(os.path.join(video_dir, videos[0]))
            return "Playing videos"
        except:
            return "Sorry, I couldn't play videos. Please check the video folder path."

    elif 'how are you' in query:
        responses = ['Just doing my thing!', 'I am fine!', 'Nice!']
        return f"{random.choice(responses)} How are you?"

    elif 'the time' in query:
        strTime = datetime.datetime.now().strftime("%H:%M:%S")
        return f"The time is {strTime}"

    elif 'your name' in query or 'sweet name' in query:
        return "Thanks for asking! My name is EVA."

    elif 'you feeling' in query:
        return "Feeling very happy to help you."

    elif 'shutdown' in query:
        return "I cannot shut down the system from the web interface for security reasons."

    elif 'good bye' in query or 'exit' in query or 'stop' in query or 'quit' in query:
        return "See you soon. Bye!"

    elif query == "none":
        return "I didn't understand that. Please try again."

    else:
        return f"I didn't understand '{query}'. Let me search it for you on Google."

# MAIN
if __name__ == "__main__":
    wishMe()
    while True:
        command = takeCommand()
        response = process_command(command)
        if response != "I didn't understand that. Please try again.":
            speak(response)
